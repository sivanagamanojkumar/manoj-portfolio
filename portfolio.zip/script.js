function toggleMenu() {
    const menu = document.querySelector(".menu-links");
    const icon = document.querySelector(".hamburger-icon");
    menu.classList.toggle("open");
    icon.classList.toggle("open");
  }
//typing effect
  const words = ["Frontend Developer", "Designer"];
    const typingSpeed = 100; // Adjust typing speed as needed
    let wordIndex = 0;
    let letterIndex = 0;
    let isDeleting = false;

    function typeText() {
      const currentWord = words[wordIndex];
      const textElement = document.querySelector('.section_text_p2');
      
      if (!isDeleting) {
        textElement.textContent = currentWord.slice(0, ++letterIndex);
      } else {
        textElement.textContent = currentWord.slice(0, --letterIndex);
      }

      if (letterIndex === currentWord.length && !isDeleting) {
        isDeleting = true;
        setTimeout(typeText, 1000); 
      } else if (letterIndex === 0 && isDeleting) {
        isDeleting = false;
        wordIndex = (wordIndex + 1) % words.length;
        setTimeout(typeText, 500); 
      } else {
        setTimeout(typeText, typingSpeed);
      }
    }

    // Start typing effect when the DOM content is loaded
    document.addEventListener('DOMContentLoaded', typeText);

    //downloading the resume
    function downloadResume() {
        // Create a link element
        var link = document.createElement('a');
        // Set the href attribute to the path of your resume PDF
        link.href = 'resume.pdf';
        // Set the download attribute to force the download
        link.download = 'resume.pdf';
        // Append the link to the body
        document.body.appendChild(link);
        // Programmatically click the link to trigger the download
        link.click();
        // Remove the link from the body
        document.body.removeChild(link);
      }